import { Hono } from "hono";
import { cors } from "hono/cors";
import { sign, verify } from "hono/jwt";
import type { Client } from "@sdk/server-types";
import { tables } from "@generated";
import { eq } from "drizzle-orm";
import Papa from "papaparse";

const JWT_SECRET = "youware-secret-key-change-this";

export async function createApp(
  edgespark: Client<typeof tables>
): Promise<Hono> {
  const app = new Hono();

  // Enable CORS
  app.use("/*", cors());

  // Helper to get Sheet URL
  async function getSheetUrl() {
    const config = await edgespark.db
      .select()
      .from(tables.adminConfig)
      .where(eq(tables.adminConfig.key, "sheet_url"))
      .get();
    return config?.value;
  }

  // Helper to fetch and parse Sheet Data
  async function fetchSheetData(url: string) {
    try {
      // Ensure URL is in CSV export format
      let csvUrl = url;
      if (url.includes("docs.google.com/spreadsheets")) {
        if (url.includes("/pubhtml")) {
           // Handle published as HTML
           csvUrl = url.replace("/pubhtml", "/pub?output=csv");
        } else if (url.includes("/edit")) {
           // Handle edit URL
           csvUrl = url.replace(/\/edit.*$/, "/export?format=csv");
        }
      }

      const response = await fetch(csvUrl);
      if (!response.ok) throw new Error("Failed to fetch sheet");
      const csvText = await response.text();
      
      const result = Papa.parse(csvText, { header: true, skipEmptyLines: true });
      return result.data as any[];
    } catch (e) {
      console.error("Sheet fetch error:", e);
      return [];
    }
  }

  // Helper to map row to user object using Arabic Column Names
  function mapRowToUser(row: any) {
    // Helper to safely parse numbers, removing currency symbols or commas
    const parseNum = (val: any) => {
      if (!val) return 0;
      if (typeof val === 'number') return val;
      return Number(val.toString().replace(/[^\d.-]/g, '')) || 0;
    };

    return {
      fullName: (row["اسم المشترك"] || row["Name"] || "").trim(),
      phoneNumber: (row["رقم المرور"] || row["Phone"] || "").toString().trim(),
      subscriberNumber: row["رقم المشترك"] || row["SubscriberID"] || "",
      sharesCount: parseNum(row["عدد الاسهم"] || row["Shares"]),
      totalSavings: parseNum(row["إجمالي مدخراتك"] || row["TotalSavings"]),
      monthlyPayment: parseNum(row["دفعة شهرية (ريال)"] || row["MonthlyPayment"]),
      baseShareValue: parseNum(row["قيمة سهم الاساس"] || row["BaseShareValue"]),
      currentShareValue: parseNum(row["قيمة سهم الحالي"] || row["CurrentShareValue"]),
      realPortfolioValue: parseNum(row["القيمة الحقيقة لمحفظتك"] || row["TotalAmount"]),
      ownershipPercentage: parseNum(row["نسبة تملك في صندوق"] || row["OwnershipPercentage"]),
      growthPercentage: parseNum(row["نسبة النمو المحفظة"] || row["GrowthPercentage"]),
      // Derived or extra fields
      totalIncome: 0, 
    };
  }

  // ==========================================
  // Admin Routes
  // ==========================================

  // Save Config
  app.post("/api/admin/config", async (c) => {
    const { sheetUrl } = await c.req.json();
    if (!sheetUrl) return c.json({ error: "URL required" }, 400);

    const existing = await edgespark.db
      .select()
      .from(tables.adminConfig)
      .where(eq(tables.adminConfig.key, "sheet_url"))
      .get();

    if (existing) {
      await edgespark.db
        .update(tables.adminConfig)
        .set({ value: sheetUrl })
        .where(eq(tables.adminConfig.key, "sheet_url"))
        .run();
    } else {
      await edgespark.db
        .insert(tables.adminConfig)
        .values({ key: "sheet_url", value: sheetUrl })
        .run();
    }

    return c.json({ success: true });
  });

  // Get Config
  app.get("/api/admin/config", async (c) => {
    const url = await getSheetUrl();
    return c.json({ sheetUrl: url || "" });
  });

  // Get All Subscribers (Admin)
  app.get("/api/admin/subscribers", async (c) => {
    const sheetUrl = await getSheetUrl();
    if (!sheetUrl) return c.json({ error: "System not configured" }, 503);

    const data = await fetchSheetData(sheetUrl);
    const subscribers = data.map(mapRowToUser).filter(u => u.fullName); 

    return c.json(subscribers);
  });

  // ==========================================
  // User Routes
  // ==========================================

  // User Login
  app.post("/api/login", async (c) => {
    const { fullName, phoneNumber } = await c.req.json();
    
    if (!fullName || !phoneNumber) {
      return c.json({ error: "Missing credentials" }, 400);
    }

    const sheetUrl = await getSheetUrl();
    if (!sheetUrl) {
      return c.json({ error: "System not configured" }, 503);
    }

    const data = await fetchSheetData(sheetUrl);
    
    // Find user with First/Last name matching logic
    const inputParts = fullName.trim().split(/\s+/);
    const inputFirst = inputParts[0];
    const inputLast = inputParts[inputParts.length - 1];

    const user = data.find((row: any) => {
      const rowName = (row["اسم المشترك"] || row["Name"] || "").trim();
      const rowPhone = (row["رقم المرور"] || row["Phone"] || "").toString().trim();
      
      // Phone check
      if (rowPhone !== phoneNumber.trim()) return false;

      // Name check
      const rowParts = rowName.split(/\s+/);
      if (rowParts.length === 0) return false;

      // If input has only 1 part, match exact or first
      if (inputParts.length === 1) {
        return rowName === fullName.trim();
      }

      // Match First Name AND Last Name
      const rowFirst = rowParts[0];
      const rowLast = rowParts[rowParts.length - 1];

      return rowFirst === inputFirst && rowLast === inputLast;
    });

    if (!user) {
      return c.json({ error: "Invalid credentials" }, 401);
    }

    const mappedUser = mapRowToUser(user);

    // Create Token
    const payload = {
      sub: mappedUser.subscriberNumber || "unknown",
      name: mappedUser.fullName,
      role: "user",
      exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24, // 24 hours
      data: mappedUser 
    };

    const token = await sign(payload, JWT_SECRET, "HS256");

    return c.json({ 
      token,
      user: mappedUser
    });
  });

  // Get User Data (Protected)
  app.get("/api/user/me", async (c) => {
    const authHeader = c.req.header("Authorization");
    if (!authHeader) return c.json({ error: "Unauthorized" }, 401);

    const token = authHeader.split(" ")[1];
    try {
      const payload = await verify(token, JWT_SECRET, "HS256");
      
      const sheetUrl = await getSheetUrl();
      if (sheetUrl) {
        const data = await fetchSheetData(sheetUrl);
        const freshUser = data.find((row: any) => {
           const rowName = (row["اسم المشترك"] || row["Name"] || "").trim();
           return rowName === payload.name;
        });

        if (freshUser) {
           return c.json(mapRowToUser(freshUser));
        }
      }

      return c.json(payload.data || payload);
    } catch (e) {
      return c.json({ error: "Invalid token" }, 401);
    }
  });

  return app;
}

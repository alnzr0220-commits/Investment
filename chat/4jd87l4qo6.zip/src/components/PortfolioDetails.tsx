import React from 'react';
import { PortfolioData } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { TrendingUp, DollarSign } from 'lucide-react';

interface PortfolioDetailsProps {
  data: PortfolioData;
}

const COLORS = ['#0ea5e9', '#6366f1', '#10b981', '#f59e0b', '#ec4899'];

export const PortfolioDetails: React.FC<PortfolioDetailsProps> = ({ data }) => {
  const chartData = data.items.map(item => ({
    name: item.companyName,
    value: item.totalValueSAR
  }));

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-bold text-gray-900">تفاصيل الشركات والمحفظة</h3>
        <div className="flex items-center space-x-2 space-x-reverse text-sm text-green-600 bg-green-50 px-3 py-1 rounded-full">
          <TrendingUp className="h-4 w-4" />
          <span>أداء إيجابي</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Table Section */}
        <div className="lg:col-span-2 overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الشركة</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الرمز</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الوحدات</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">سعر السوق</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">القيمة ($)</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">القيمة (ر.س)</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {data.items.map((item, index) => (
                <tr key={index} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.companyName}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">{item.assetSymbol}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{item.units}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{item.marketPrice}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${item.totalValueUSD.toLocaleString()}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm font-bold text-primary-600">{item.totalValueSAR.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-gray-50">
              <tr>
                <td colSpan={5} className="px-4 py-4 text-sm font-bold text-gray-900 text-left pl-8">إجمالي قيمة المحفظة</td>
                <td className="px-4 py-4 whitespace-nowrap text-lg font-bold text-primary-700">{data.totalPortfolioValue.toLocaleString()} ر.س</td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Chart Section */}
        <div className="h-80 lg:h-auto min-h-[300px] bg-gray-50 rounded-xl p-4 flex flex-col items-center justify-center relative">
          <h4 className="text-sm font-medium text-gray-500 mb-4 absolute top-4 right-4">توزيع الأصول</h4>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                fill="#8884d8"
                paddingAngle={5}
                dataKey="value"
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => `${value.toLocaleString()} ر.س`} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { Save, Database, LogOut, CheckCircle, AlertCircle, Search, User, Eye, Settings } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';
import { Subscriber } from '../types';

export const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'list' | 'config'>('list');
  const [subscribers, setSubscribers] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [sheetUrl, setSheetUrl] = useState('');
  const [isSaved, setIsSaved] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [config, subs] = await Promise.all([
        api.getConfig().catch(() => ({ sheetUrl: '' })),
        api.getAllSubscribers().catch(() => [])
      ]);
      if (config.sheetUrl) setSheetUrl(config.sheetUrl);
      setSubscribers(subs);
    } catch (err) {
      console.error(err);
      setError('فشل تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      await api.saveConfig(sheetUrl);
      setIsSaved(true);
      setTimeout(() => setIsSaved(false), 3000);
      // Reload subscribers after config change
      const subs = await api.getAllSubscribers();
      setSubscribers(subs);
    } catch (err) {
      setError('فشل حفظ الإعدادات');
    } finally {
      setLoading(false);
    }
  };

  const filteredSubscribers = subscribers.filter(sub => {
    const query = searchQuery.toLowerCase();
    return (
      (sub.fullName || '').toLowerCase().includes(query) ||
      (sub.phoneNumber || '').includes(query) ||
      (sub.subscriberNumber || '').toLowerCase().includes(query)
    );
  });

  const handleViewUser = (subscriber: any) => {
    // Navigate to view page with state
    navigate(`/admin/view/${subscriber.subscriberNumber}`, { state: { subscriber } });
  };

  return (
    <div className="min-h-screen bg-gray-100" dir="rtl">
      <nav className="bg-gray-900 shadow-lg sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Database className="h-8 w-8 text-indigo-500" />
              <span className="mr-3 text-white font-bold text-lg">لوحة الإدمن</span>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <button 
                onClick={() => setActiveTab('list')}
                className={`px-3 py-2 rounded-md text-sm font-medium ${activeTab === 'list' ? 'bg-gray-800 text-white' : 'text-gray-300 hover:text-white'}`}
              >
                المشتركين
              </button>
              <button 
                onClick={() => setActiveTab('config')}
                className={`px-3 py-2 rounded-md text-sm font-medium ${activeTab === 'config' ? 'bg-gray-800 text-white' : 'text-gray-300 hover:text-white'}`}
              >
                الإعدادات
              </button>
              <button 
                onClick={() => navigate('/admin')}
                className="text-red-400 hover:text-red-300 flex items-center mr-4"
              >
                <LogOut className="h-5 w-5 ml-2" />
                خروج
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
        {activeTab === 'list' ? (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-center bg-white p-4 rounded-lg shadow gap-4">
              <div className="relative w-full sm:w-96">
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  className="block w-full pr-10 border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-3 border"
                  placeholder="بحث بالاسم، الجوال، أو رقم المشترك..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="text-sm text-gray-500">
                عدد المشتركين: {filteredSubscribers.length}
              </div>
            </div>

            <div className="bg-white shadow overflow-hidden sm:rounded-md">
              <ul className="divide-y divide-gray-200">
                {filteredSubscribers.length > 0 ? (
                  filteredSubscribers.map((sub, index) => (
                    <li key={index}>
                      <div className="block hover:bg-gray-50 cursor-pointer" onClick={() => handleViewUser(sub)}>
                        <div className="px-4 py-4 sm:px-6">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <div className="flex-shrink-0 h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold">
                                {sub.fullName?.charAt(0)}
                              </div>
                              <div className="mr-4">
                                <p className="text-sm font-medium text-indigo-600 truncate">{sub.fullName}</p>
                                <p className="flex items-center text-sm text-gray-500">
                                  <User className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                                  {sub.subscriberNumber}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center">
                              <div className="ml-4 flex-shrink-0 flex flex-col items-end">
                                <p className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                  {Number(sub.sharesCount).toLocaleString()} سهم
                                </p>
                                <p className="mt-1 text-sm text-gray-900 font-bold">
                                  {Number(sub.realPortfolioValue).toLocaleString()} ر.س
                                </p>
                              </div>
                              <Eye className="h-5 w-5 text-gray-400 mr-4" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                  ))
                ) : (
                  <li className="px-4 py-8 text-center text-gray-500">
                    {loading ? 'جاري التحميل...' : 'لا يوجد مشتركين مطابقين للبحث'}
                  </li>
                )}
              </ul>
            </div>
          </div>
        ) : (
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900 flex items-center">
                <Settings className="ml-2 h-5 w-5 text-gray-500" />
                إعدادات مصدر البيانات
              </h3>
              <div className="mt-2 max-w-xl text-sm text-gray-500">
                <p>
                  رابط Google Sheet (CSV) المستخدم لجلب البيانات.
                </p>
              </div>
              
              <form className="mt-5" onSubmit={handleSave}>
                <div className="w-full sm:max-w-2xl">
                  <label htmlFor="sheet-url" className="block text-sm font-medium text-gray-700">
                    رابط Google Sheet
                  </label>
                  <div className="mt-1">
                    <input
                      type="url"
                      name="sheet-url"
                      id="sheet-url"
                      className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md p-3 border"
                      placeholder="https://docs.google.com/spreadsheets/d/..."
                      value={sheetUrl}
                      onChange={(e) => setSheetUrl(e.target.value)}
                    />
                  </div>
                </div>
                
                <div className="mt-5">
                  <button
                    type="submit"
                    disabled={loading}
                    className="inline-flex items-center justify-center px-4 py-2 border border-transparent shadow-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:text-sm disabled:opacity-50"
                  >
                    {loading ? 'جاري الحفظ...' : (
                      <>
                        <Save className="ml-2 -mr-1 h-5 w-5" />
                        حفظ الإعدادات
                      </>
                    )}
                  </button>
                </div>
              </form>

              {isSaved && (
                <div className="mt-4 rounded-md bg-green-50 p-4">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <CheckCircle className="h-5 w-5 text-green-400" />
                    </div>
                    <div className="mr-3">
                      <p className="text-sm font-medium text-green-800">
                        تم حفظ الرابط بنجاح!
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

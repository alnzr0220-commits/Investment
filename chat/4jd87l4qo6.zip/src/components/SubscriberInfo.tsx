import React from 'react';
import { Subscriber } from '../types';
import { 
  Hash,
  Activity,
  DollarSign,
  User,
  PiggyBank,
  CreditCard,
  Wallet,
  TrendingUp,
  Percent
} from 'lucide-react';

interface SubscriberInfoProps {
  subscriber: Subscriber;
}

export const SubscriberInfo: React.FC<SubscriberInfoProps> = ({ subscriber }) => {
  const stats = [
    { label: 'رقم المشترك', value: subscriber.subscriberNumber, icon: Hash, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'عدد الأسهم', value: subscriber.sharesCount.toLocaleString(), icon: Activity, color: 'text-indigo-600', bg: 'bg-indigo-100' },
    { label: 'إجمالي المدخرات', value: `${subscriber.totalSavings.toLocaleString()} ر.س`, icon: PiggyBank, color: 'text-emerald-600', bg: 'bg-emerald-100' },
    { label: 'الدفعة الشهرية', value: `${subscriber.monthlyPayment.toLocaleString()} ر.س`, icon: CreditCard, color: 'text-purple-600', bg: 'bg-purple-100' },
    { label: 'قيمة سهم الأساس', value: `${subscriber.baseShareValue} ر.س`, icon: Wallet, color: 'text-gray-600', bg: 'bg-gray-100' },
    { label: 'قيمة السهم الحالي', value: `${subscriber.currentShareValue} ر.س`, icon: TrendingUp, color: 'text-orange-600', bg: 'bg-orange-100' },
    { label: 'القيمة الحقيقية للمحفظة', value: `${subscriber.realPortfolioValue.toLocaleString()} ر.س`, icon: DollarSign, color: 'text-teal-600', bg: 'bg-teal-100' },
    { label: 'نسبة التملك في الصندوق', value: `${subscriber.ownershipPercentage}%`, icon: Percent, color: 'text-cyan-600', bg: 'bg-cyan-100' },
    { label: 'نسبة النمو للمحفظة', value: `${subscriber.growthPercentage}%`, icon: TrendingUp, color: 'text-green-600', bg: 'bg-green-100' },
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-bold text-gray-900">بيانات المشترك</h3>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="flex items-center p-4 rounded-lg border border-gray-50 bg-gray-50">
          <div className="h-12 w-12 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 font-bold text-xl ml-4">
            <User className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm text-gray-500 mb-1">اسم المشترك</p>
            <p className="text-lg font-bold text-gray-900">{subscriber.fullName}</p>
          </div>
        </div>

        {stats.map((stat, index) => (
          <div key={index} className="flex items-center p-4 rounded-lg border border-gray-50 hover:bg-gray-50 transition-colors">
            <div className={`h-12 w-12 rounded-lg ${stat.bg} flex items-center justify-center ml-4`}>
              <stat.icon className={`h-6 w-6 ${stat.color}`} />
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">{stat.label}</p>
              <p className="text-xl font-bold text-gray-900">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
